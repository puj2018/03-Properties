Please Note:
1. Files or programs provided in this directory are not a part of MSU ProFlex, 
   but created by PSA Lab as utilities to use along with MSU ProFlex software. 
2. To compile the executable 'asgn_max_rgd' on Unix, type 'make' on command line. 
   Use g++ compiler version 2.95.2 or greater.
