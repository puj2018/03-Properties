Thank you for downloading the MMTSB Tool Set.

To install, go to the 'src' directory and type 'make'.

The Makefile assumes gcc/g++/gfortran and needs to be 
adjusted if you wnat to use a different compiler.

Set MMTSBDIR to the top MMTSB directory and
add $MMTSBDIR/perl and $MMSTBDIR/bin to your path.

If you have CHARMM available, please also set CHARMMEXEC"
and CHARMMDATA to the location of the executable and
CHARMM data directory (for parameter and toplogy files). 

Documentation is available at: http://feig.bch.msu.edu/mmtsb

Please send comments/questions to mmtsbtoolset@gmail.com



